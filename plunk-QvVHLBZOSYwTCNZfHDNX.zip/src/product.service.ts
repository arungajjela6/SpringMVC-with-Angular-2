import {Injectable} from '@angular/core';
import {Http,Headers,Response,RequestOptions} from '@angular/http';
import {Observable} from 'rxjs/Rx';
import 'rxjs/add/operator/map';

@Injectable()
export class ProductService{
  
  constructor(private http:Http){}
  
  fetchAllProducts(){
    console.log("****fetchAllProducts()***");
    return this.http.get("http://localhost:8080/Restfulser/rest/productService/list").map(res => res.json());
  }
  
}