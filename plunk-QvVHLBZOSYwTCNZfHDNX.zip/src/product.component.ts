import {Component,OnInit} from '@angular/core';
import {Observable} from 'rxjs/Rx';
import {ProductService} from './product.service';

@Component({
  selector: 'my-app',
  template: `
    <div class="container">
      
      <h2 align=center>Product Records</h2>
      
      <table class="table">
      
        <tr>
          <th>ProductId</th><th>ProductName</th><th>ProductPrice</th><th>ProductDescription</th>    
        </tr>
        
        <tr *ngFor="let product of products">
          <td>{{product.id}}</td>
          <td>{{product.name}}</td>
          <td>{{product.dept}}</td>
          <td>{{product.price}}</td>
        </tr>
      
      </table>
      
    </div>`,
    providers:[ProductService]
})
export class ProductComponent implements OnInit{
  
  constructor(private productService:ProductService){}
  products=[];
  
  ngOnInit(){
    console.log("****ngOnInit()***");
    this.productService.fetchAllProducts().subscribe(data => {this.products=data});
  }
  
}